package states;

import java.io.Serializable;

public class StatePlayerNormal extends State implements Serializable{

}
